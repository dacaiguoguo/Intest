from django.apps import AppConfig


class IntestConfig(AppConfig):
    name = 'intest'
