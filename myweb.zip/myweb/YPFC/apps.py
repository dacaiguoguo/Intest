from django.apps import AppConfig


class YpfcConfig(AppConfig):
    name = 'YPFC'
