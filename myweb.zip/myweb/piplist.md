[
    {
        "version": "1.1", 
        "name": "accmon"
    }, 
    {
        "version": "4.7", 
        "name": "antlr4-python3-runtime"
    }, 
    {
        "version": "1.4.3", 
        "name": "appdirs"
    }, 
    {
        "version": "4.6.0", 
        "name": "beautifulsoup4"
    }, 
    {
        "version": "1.5.0", 
        "name": "bleach"
    }, 
    {
        "version": "0.0.1", 
        "name": "bs4"
    }, 
    {
        "version": "2017.4.17", 
        "name": "certifi"
    }, 
    {
        "version": "3.0.3", 
        "name": "chardet"
    }, 
    {
        "version": "3.5.0", 
        "name": "configparser"
    }, 
    {
        "version": "1.4.1", 
        "name": "crypto"
    }, 
    {
        "version": "1.10.7", 
        "name": "Django"
    }, 
    {
        "version": "8.2.3", 
        "name": "django-bootstrap3"
    }, 
    {
        "version": "0.8.0", 
        "name": "django-classy-tags"
    }, 
    {
        "version": "0.8.7", 
        "name": "django-mptt"
    }, 
    {
        "version": "1.0b3", 
        "name": "django-nyt"
    }, 
    {
        "version": "0.10.0", 
        "name": "django-sekizai"
    }, 
    {
        "version": "0.1.0", 
        "name": "django-simplemde"
    }, 
    {
        "version": "0.5", 
        "name": "django-system-monitor"
    }, 
    {
        "version": "0.2.3", 
        "name": "EasyProcess"
    }, 
    {
        "version": "1.1", 
        "name": "fodtlmon"
    }, 
    {
        "version": "0.9999999", 
        "name": "html5lib"
    }, 
    {
        "version": "2.6.8", 
        "name": "Markdown"
    }, 
    {
        "version": "2.0.3", 
        "name": "multi-key-dict"
    }, 
    {
        "version": "2.1.4", 
        "name": "mysql-connector"
    }, 
    {
        "version": "0.1.31", 
        "name": "Naked"
    }, 
    {
        "version": "0.44", 
        "name": "olefile"
    }, 
    {
        "version": "16.8", 
        "name": "packaging"
    }, 
    {
        "version": "3.0.1", 
        "name": "pbr"
    }, 
    {
        "version": "4.1.1", 
        "name": "Pillow"
    }, 
    {
        "version": "9.0.1", 
        "name": "pip"
    }, 
    {
        "version": "3.3.0", 
        "name": "protobuf"
    }, 
    {
        "version": "1.2.1", 
        "name": "psutil"
    }, 
    {
        "version": "0.10.4", 
        "name": "py4j"
    }, 
    {
        "version": "2.6.1", 
        "name": "pycrypto"
    }, 
    {
        "version": "7.43.0", 
        "name": "pycurl"
    }, 
    {
        "version": "0.7.11", 
        "name": "PyMySQL"
    }, 
    {
        "version": "2.2.0", 
        "name": "pyparsing"
    }, 
    {
        "version": "3.3", 
        "name": "pyserial"
    }, 
    {
        "version": "0.1.6", 
        "name": "pytesseract"
    }, 
    {
        "version": "0.2.3", 
        "name": "python-gtmetrix"
    }, 
    {
        "version": "0.4.14", 
        "name": "python-jenkins"
    }, 
    {
        "version": "0.2.1", 
        "name": "PyVirtualDisplay"
    }, 
    {
        "version": "3.12", 
        "name": "PyYAML"
    }, 
    {
        "version": "2.14.2", 
        "name": "requests"
    }, 
    {
        "version": "3.0.2", 
        "name": "robotframework"
    }, 
    {
        "version": "0.4.7", 
        "name": "robotframework-requests"
    }, 
    {
        "version": "3.4.2", 
        "name": "selenium"
    }, 
    {
        "version": "35.0.2", 
        "name": "setuptools"
    }, 
    {
        "version": "3.4.1", 
        "name": "shellescape"
    }, 
    {
        "version": "1.10.0", 
        "name": "six"
    }, 
    {
        "version": "12.3", 
        "name": "sorl-thumbnail"
    }, 
    {
        "version": "2.0.15", 
        "name": "uWSGI"
    }, 
    {
        "version": "0.24.0", 
        "name": "wheel"
    }, 
    {
        "version": "0.2.4", 
        "name": "wiki"
    }
]