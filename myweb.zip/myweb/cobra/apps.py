from django.apps import AppConfig


class CobraConfig(AppConfig):
    name = 'cobra'
