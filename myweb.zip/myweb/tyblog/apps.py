#!usr/bin/env python
# -*- coding: utf-8 -*-

from django.apps import AppConfig


class TyblogConfig(AppConfig):
    name = 'tyblog'
