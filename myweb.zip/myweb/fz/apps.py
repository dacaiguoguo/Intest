from django.apps import AppConfig


class FzConfig(AppConfig):
    name = 'fz'
